# Free Remote Commander VPS 1.2 — Ubuntu / Docker Engine standalone

**Status:** Quellcode lokal geprueft; **nicht auf dem Produktions-VPS installiert**.

Dies ist eine eigenstaendige, auf einen einzelnen neuen Ordner beschraenkte MCP-Implementierung.
Keine Shell, keine Prozesssteuerung, kein Host-/Docker-Management und keine Loeschfunktionen.
Es ist keine proprietaere 1:1-Kopie von Remote Desktop Commander.

## WICHTIG: Geeignet fuer den bestehenden Ubuntu-VPS

- Bestehende Docker Engine ab Version 28 (geprueft in den Voraussetzungen: Docker Engine 29.1.3).
- `docker compose` wird **nicht** gebraucht, installiert oder veraendert.
- Der Installer fuehrt **kein apt**, kein Docker-Upgrade und keinen Docker-Daemon-Neustart aus.
- Er stoppt keine bestehenden Container und veraendert weder Nginx, PostgreSQL noch die Firewall.
- Ausgefuehrt wird das Startskript als Host-Administrator (root), aber der neue Container
  laeuft ausschliesslich als unprivilegierte numerische UID `65050:65050`.
- Es wird ausschliesslich der **neue, bislang nicht vorhandene** Ordner `workspace`
  aus dem entpackten Projekt in den Container eingebunden. Bestehende Ordner
  koennen mit diesem Installer absichtlich **nicht** freigegeben werden.
- TCP `127.0.0.1:17887` ist nur auf dem VPS lokal gebunden. **Kein offener externer Port.**
- Separates Docker-Netzwerk `frc-vps-internal-12` mit `--internal`.
- Root-Dateisystem des Containers schreibgeschuetzt, keine Linux-Capabilities,
  `no-new-privileges`, Prozess- und Ressourcengrenzen, kein Docker-Socket.
- Ein Secret wird frisch erzeugt in `.env` (`0600`). **Niemals Inhalt oder URL veroeffentlichen.**
- Das Host-Docker selbst ist ein hochprivilegierter Dienst. Isolierung reduziert
  das Risiko, bietet aber keine mathematische Sicherheitsgarantie.

## 1. Vorab: Zustand lesen, bevor irgendetwas installiert wird

In der Netcup-VNC-Konsole als `root`:

```bash
docker --version
docker ps
ss -lnt
command -v openssl
command -v curl
command -v tar
```

Alle Befehle lesen nur den Systemzustand. Prüfe, ob `127.0.0.1:17887`
noch nicht belegt ist. Nichts installieren, wenn eine Fehlermeldung unklar ist.

## 2. Paket sicher auf den VPS uebertragen

Lade zuerst `Free-Remote-Commander-VPS-Ubuntu-1.2.tar.gz` herunter.
Die Datei muss in einer von dir kontrollierten Weise zum VPS kommen.
Unter einer Firmen-Firewall nicht eigenmaechtig SSH- oder Netzwerkbeschraenkungen umgehen.
Moegliche Wege: vom privat autorisierten Computer per SCP/SFTP oder von einem
von dir genehmigten vertrauenswuerdigen HTTPS-Download-Ort direkt in der
VPS-Konsole via `curl`. **Die ChatGPT-sandbox-Downloadadresse kann nicht direkt
auf dem VPS via curl heruntergeladen werden.**

Datei nach `/root` uebertragen, anschließend:

```bash
cd /root
tar -xzf Free-Remote-Commander-VPS-Ubuntu-1.2.tar.gz
cd free-remote-commander-vps
```

Keine unbekannten Links / Shell-Einzeiler aus dem Internet nutzen. Keine
Zugangsdaten in Chat-Nachrichten kopieren.

## 3. Installation via vorhandener Docker Engine — ohne Docker Compose

```bash
bash scripts/install.sh
```

Abbruch bei bereits belegtem Port, Container-/Netzwerknamen, Ordner,
Image-Tag, besetzter UID 65050 oder fehlenden Voraussetzungen.
Der Installer laedt das offizielle Node.js 22 Alpine Image bei Bedarf von Docker Hub,
baut ein neues Image und startet ausschliesslich den neuen Container
`frc-vps-folder-12` im separaten Netzwerk `frc-vps-internal-12`.
Vorliegende Container und Images werden nicht aktualisiert oder entfernt.

**Achtung:** Image-Downloads und die Image-Build-Phase verwenden Docker selbst;
auf einem produktiven Host immer freien Speicher und Ressourcen kontrollieren.

## 4. Laufzeitsicherheit pruefen (nach erfolgreicher Installation)

```bash
bash scripts/verify.sh
```

9 Checks: zugehoeriger Container laeuft, lokale Healthantwort, MCP-Handshake,
Tool-Liste ohne Shell/Loeschen, Traversal-Schutz, falsche Secret-URL 404,
nur localhost-Port, Container-Sicherheitsoptionen und internes Netzwerk.

Weitere direkte Zustandspruefung:

```bash
docker ps
docker inspect frc-vps-folder-12
```

ACHTUNG: `docker inspect` zeigt potentiell das Secret unter den Env-Variablen.
**Keine Screenshots der vollstaendigen Docker-Inspect-Ausgabe schicken.**
Im Support bitte nur Ergebnisse von `bash scripts/verify.sh` und `docker ps` teilen.

Bei fehlgeschlagenem Healthcheck stoppt `install.sh` nur den neu geschaffenen
Container. Den oeffentlichen Tunnel keinesfalls vor erfolgreichem Runtime-Test starten.

## 5. ChatGPT-Remote-MCP: separater zweiter Schritt

Die Installation stellt den MCP-Server **nicht** oeffentlich bereit.
Eine Remote-Anbindung erfordert einen HTTPS-Endpunkt mit angemessener
Authentifizierung und Domain/Tunnel-Konfiguration. `scripts/tunnel-dev.sh`
ist nur fuer einen vom Betreiber ausdruecklich autorisierten Einzelnutzer-Test
geeignet (Quick Tunnel ohne OAuth ist kein Produktionsschutz; die URL selbst
ist der einzige Zugangsschutz). Keine Sicherheitsvorgaben von Arbeitsplaetzen
oder Organisationen umgehen.

Das Paket enthaelt `plugin-template/mcp.example.json` als Referenz fuer
Streamable HTTP. Vollstaendige Verifikation mit ChatGPT kann erst nach der
entsprechenden sicheren Freigabe erfolgen.

## 6. Vollstaendiger Rueckbau (nur unser eigener Stack)

```bash
cd /root/free-remote-commander-vps
bash scripts/uninstall.sh
```

Entfernt nur den Container und das Docker-Netzwerk mit genau unserem Namen
und Sicherheitslabel. Bestehende Container bleiben unangetastet.
Workspace, `.env`, Image und Quellcode bleiben zur manuellen Kontrolle erhalten.
Falls ein Remote-Tunnel separat konfiguriert wurde, ihn separat abschalten.

## 7. Moegliche Rest-Risiken

- Root muss den Docker-Container erstmals anlegen; der Docker-Daemon hat weitgehende Host-Rechte.
- Sicherheitsupdates fuer Ubuntu, Docker und Basisimages bleiben Betreiberaufgabe.
- Schreibzugriff auf den freigegebenen Ordner bleibt moeglich und beabsichtigt.
- Ein erlangter privater MCP-Pfad gestattet Ordnerzugriff; ohne OAuth nicht produktiv exponieren.
- Ohne Live-Zugriff auf den VPS kann dieses Paket nicht beweisen, dass die Docker-Run-Optionen
  und der interne Netzwerkmodus in der konkreten Hostkonfiguration bereits funktionieren.
- Docker Portveroeffentlichungen und hosteigene Filterregeln sind deployment-spezifisch;
  das Skript prueft den Loopback-Zugriff und bricht bei Misserfolg ab.
