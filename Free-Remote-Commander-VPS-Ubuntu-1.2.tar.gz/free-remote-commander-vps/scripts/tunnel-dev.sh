#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
if [[ ! -f "$ROOT/.env" ]]; then echo 'ERROR: Install first.' >&2; exit 1; fi
if ! command -v cloudflared >/dev/null; then echo 'ERROR: cloudflared is not installed. Do not install without reviewing your VPS.' >&2; exit 1; fi
PORT="$(sed -n 's/^FRC_PORT=//p' "$ROOT/.env")"
cat <<'TXT'
WARNING: This temporary Cloudflare Quick Tunnel is for TESTING, not production.
Possession of the private MCP URL grants workspace access (capability URL).
Never publish the full URL, send it to strangers, or put it in a public repo.
Use a named Cloudflare Tunnel and properly configured OAuth for production.
TXT
exec cloudflared tunnel --url "http://127.0.0.1:$PORT"
