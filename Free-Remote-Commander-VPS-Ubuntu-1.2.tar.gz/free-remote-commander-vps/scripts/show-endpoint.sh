#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
if [[ ! -f "$ROOT/.env" ]]; then echo 'ERROR: Install first.' >&2; exit 1; fi
SECRET="$(sed -n 's/^FRC_MCP_PATH=//p' "$ROOT/.env")"
printf 'Local MCP endpoint (private; do not publish): http://127.0.0.1:17887%s\n' "$SECRET"
printf 'For Cloudflare tunnel: https://YOUR-NEW-SUBDOMAIN%s\n' "$SECRET"
