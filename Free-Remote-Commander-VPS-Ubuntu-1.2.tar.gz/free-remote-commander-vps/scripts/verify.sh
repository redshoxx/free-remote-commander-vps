#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
NAME='frc-vps-folder-12'
NET='frc-vps-internal-12'
PORT=17887
WORKSPACE="$ROOT/workspace"
[[ -f "$ROOT/.env" ]] || { echo 'Missing .env: install first' >&2; exit 1; }
PATH_SECRET="$(sed -n 's/^FRC_MCP_PATH=//p' "$ROOT/.env")"
[[ "$PATH_SECRET" =~ ^/mcp/[0-9a-f]{64}$ ]] || { echo 'Invalid local endpoint secret' >&2; exit 1; }
URL="http://127.0.0.1:$PORT$PATH_SECRET"
post() { curl -fsS --max-time 10 -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' --data "$1" "$URL"; }

printf '[1/9] Standalone container running ... '
[[ "$(docker inspect -f '{{.State.Running}}' "$NAME")" == true ]]
[[ "$(docker inspect -f '{{index .Config.Labels "frc.owner"}}' "$NAME")" == "$NAME" ]]
echo OK
printf '[2/9] Local health ... '
[[ "$(curl -fsS --max-time 8 "http://127.0.0.1:$PORT/health")" == *'"ok"'* ]]
echo OK
printf '[3/9] MCP initialize ... '
[[ "$(post '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}')" == *'"protocolVersion"'* ]]
echo OK
printf '[4/9] Allowed tools only ... '
TOOLS="$(post '{"jsonrpc":"2.0","id":2,"method":"tools/list"}')"
[[ "$TOOLS" == *'"list_directory"'* && "$TOOLS" != *'"delete_file"'* && "$TOOLS" != *'"execute_command"'* ]]
echo OK
printf '[5/9] Path traversal rejected ... '
ATTACK="$(post '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"read_text_file","arguments":{"path":"../../etc/passwd"}}}')"
[[ "$ATTACK" == *'"isError":true'* ]]
echo OK
printf '[6/9] Invalid endpoint rejected ... '
[[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "http://127.0.0.1:$PORT/mcp/not-authorized")" == 404 ]]
echo OK
printf '[7/9] Port bound to localhost only ... '
LINE="$(ss -ltnH | grep ':17887' || true)"
[[ "$LINE" == *'127.0.0.1:'* && "$LINE" != *'0.0.0.0:'* && "$LINE" != *'[::]:'* ]]
echo OK
printf '[8/9] Isolation and mount ... '
[[ "$(docker inspect -f '{{.HostConfig.ReadonlyRootfs}}' "$NAME")" == true ]]
[[ "$(docker inspect -f '{{.HostConfig.Privileged}}' "$NAME")" == false ]]
[[ "$(docker inspect -f '{{json .HostConfig.CapDrop}}' "$NAME")" == *ALL* ]]
[[ "$(docker inspect -f '{{json .HostConfig.SecurityOpt}}' "$NAME")" == *no-new-privileges* ]]
[[ "$(docker inspect -f '{{.Config.User}}' "$NAME")" == 65050:65050 ]]
MOUNTS="$(docker inspect -f '{{json .Mounts}}' "$NAME")"
[[ "$MOUNTS" == *"$WORKSPACE"* && "$MOUNTS" != *docker.sock* ]]
echo OK
printf '[9/9] Dedicated internal network ... '
[[ "$(docker network inspect -f '{{.Internal}}' "$NET")" == true ]]
[[ "$(docker network inspect -f '{{index .Labels "frc.owner"}}' "$NET")" == "$NAME" ]]
echo OK
printf '\nAll nine runtime checks passed. Existing containers were not inspected or changed by the installer.\n'
