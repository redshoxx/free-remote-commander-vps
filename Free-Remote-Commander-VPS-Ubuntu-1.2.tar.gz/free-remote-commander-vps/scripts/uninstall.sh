#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run as root on VPS.' >&2; exit 1; }
NAME='frc-vps-folder-12'
NET='frc-vps-internal-12'
LABEL="$(docker inspect -f '{{index .Config.Labels "frc.owner"}}' "$NAME" 2>/dev/null || true)"
if [[ -n "$LABEL" && "$LABEL" != "$NAME" ]]; then echo 'Unexpected container owner label; stopping.' >&2; exit 1; fi
if [[ "$LABEL" == "$NAME" ]]; then docker rm -f "$NAME"; fi
if docker network inspect "$NET" >/dev/null 2>&1; then
  NETWORK_OWNER="$(docker network inspect -f '{{index .Labels "frc.owner"}}' "$NET")"
  if [[ "$NETWORK_OWNER" == "$NAME" ]]; then docker network rm "$NET"; fi
fi
printf 'Only our own container/network removed. Workspace, .env and image were preserved.\n'
