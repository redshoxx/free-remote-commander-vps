#!/usr/bin/env bash
# Free Remote Commander - Docker Engine-only installer (no Compose, no apt)
set -euo pipefail
umask 077
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$ROOT"
NAME='frc-vps-folder-12'
NET='frc-vps-internal-12'
IMAGE='frc-vps-folder:1.2-local'
WORKSPACE="$ROOT/workspace"
PORT='17887'
RUNTIME_UID='65050'

fail() { printf 'ABORT: %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail 'Run this installer as root only from the VPS console. The container itself runs unprivileged.'
[[ -d "$ROOT/server" && -f "$ROOT/Dockerfile" ]] || fail 'Project files missing.'
[[ ! -e "$ROOT/.env" ]] || fail 'Configuration already exists: refusing to overwrite.'
[[ ! -e "$WORKSPACE" && ! -L "$WORKSPACE" ]] || fail 'Workspace already exists: refusing to expose an existing folder.'
[[ "$(realpath -m -- "$ROOT")" == "$ROOT" ]] || fail 'Project directory must be canonical.'
for cmd in docker openssl curl ss getent; do command -v "$cmd" >/dev/null || fail "Required program not found: $cmd"; done
[[ -z "$(getent passwd "$RUNTIME_UID" || true)" ]] || fail "Host UID $RUNTIME_UID is already occupied; do not reuse without review."
SERVER_VERSION="$(docker version --format '{{.Server.Version}}' 2>/dev/null)" || fail 'Docker daemon unavailable.'
MAJOR="${SERVER_VERSION%%.*}"
[[ "$MAJOR" =~ ^[0-9]+$ ]] && (( MAJOR >= 28 )) || fail 'Docker Engine 28+ is required.'
if ss -ltnH | grep -Eq '(^|:)17887([[:space:]]|$)'; then fail 'TCP port 17887 is already occupied.'; fi
if docker container inspect "$NAME" >/dev/null 2>&1; then fail "Container name $NAME is in use."; fi
if docker network inspect "$NET" >/dev/null 2>&1; then fail "Network name $NET is in use."; fi
if docker image inspect "$IMAGE" >/dev/null 2>&1; then fail "Image name $IMAGE is in use."; fi

printf 'Docker Engine %s found. Building a new image; existing images/containers will not be stopped.\n' "$SERVER_VERSION"
docker build -t "$IMAGE" -f Dockerfile "$ROOT"
mkdir -- "$WORKSPACE"
chown "$RUNTIME_UID:$RUNTIME_UID" "$WORKSPACE"
chmod 0700 "$WORKSPACE"
SECRET="$(openssl rand -hex 32)"
printf 'FRC_MCP_PATH=/mcp/%s\nFRC_PORT=%s\n' "$SECRET" "$PORT" > "$ROOT/.env"
chmod 0600 "$ROOT/.env"

docker network create --driver bridge --internal --label 'frc.owner=frc-vps-folder-12' "$NET" >/dev/null
docker run --detach \
  --name "$NAME" \
  --label 'frc.owner=frc-vps-folder-12' \
  --user "$RUNTIME_UID:$RUNTIME_UID" \
  --network "$NET" \
  --publish "127.0.0.1:$PORT:8787" \
  --mount "type=bind,source=$WORKSPACE,target=/workspace,bind-propagation=rprivate" \
  --read-only --init --cap-drop ALL --security-opt no-new-privileges:true \
  --pids-limit 40 --memory 192m --cpus 0.5 \
  --restart unless-stopped \
  --log-driver json-file --log-opt max-size=2m --log-opt max-file=2 \
  --health-cmd="node -e \"fetch('http://127.0.0.1:8787/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))\"" \
  --health-interval=30s --health-timeout=5s --health-retries=3 \
  --env-file "$ROOT/.env" \
  --env FRC_WORKSPACE=/workspace --env FRC_LISTEN_PORT=8787 --env FRC_ALLOW_DELETE=0 \
  "$IMAGE" >/dev/null

READY=0
for i in $(seq 1 30); do
  if curl -fsS --max-time 2 "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then READY=1; break; fi
  sleep 1
done
if [[ "$READY" != 1 ]]; then
  echo 'ABORT: Local health check failed. Only the new service will be stopped.' >&2
  docker stop "$NAME" >/dev/null 2>&1 || true
  exit 1
fi
printf '\nInstalled %s (Docker Engine, no Compose).\nHost workspace: %s\nLocal port: 127.0.0.1:%s\n' "$NAME" "$WORKSPACE" "$PORT"
echo 'Do NOT display/share .env. Next: bash scripts/verify.sh'
