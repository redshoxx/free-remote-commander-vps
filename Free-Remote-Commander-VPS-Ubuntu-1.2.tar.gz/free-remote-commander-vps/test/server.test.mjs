import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { buildServer } from '../server/index.mjs';

let workspace, app, url, secret;
const HEADERS = { 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream' };
const call = async (method, params = {}, id = 1, custom = {}) => {
  const response = await fetch(url, { method: 'POST', headers: { ...HEADERS, ...custom }, body: JSON.stringify({ jsonrpc: '2.0', id, method, params }) });
  return { status: response.status, json: await response.json() };
};
const tool = async (name, args) => (await call('tools/call', { name, arguments: args })).json.result;

before(async () => {
  workspace = await fs.mkdtemp(path.join(os.tmpdir(), 'frc-vps-test-'));
  await fs.writeFile(path.join(workspace, 'fixture.txt'), 'alpha\nbeta\ngamma', 'utf8');
  await fs.symlink('/etc/passwd', path.join(workspace, 'outside-link'));
  secret = '/mcp/' + 'a'.repeat(64);
  app = await buildServer({ workspace, pathSecret: secret });
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  url = `http://127.0.0.1:${app.address().port}${secret}`;
});
after(async () => {
  await new Promise(resolve => app.close(resolve));
  await fs.rm(workspace, { recursive: true, force: true });
});

test('MCP initialize replies with supported protocol metadata', async () => {
  const {status, json} = await call('initialize');
  assert.equal(status, 200);
  assert.equal(json.result.protocolVersion, '2025-11-25');
  assert.equal(json.result.serverInfo.name, 'free-remote-commander-vps');
});
test('read-only and write tools available, no shell/delete/process tools', async () => {
  const {json} = await call('tools/list');
  const names = json.result.tools.map(t => t.name);
  assert.ok(names.includes('read_text_file'));
  assert.ok(names.includes('write_text_file'));
  assert.ok(!names.some(n => /process|execute|shell|delete|network/i.test(n)));
});
test('missing/wrong capability URL is inaccessible', async () => {
  const r = await fetch(url.replace(/a{64}$/, 'b'.repeat(64)), { method: 'POST', headers: HEADERS, body: '{}' });
  assert.equal(r.status, 404);
});
test('browser Origin is denied to prevent DNS rebinding', async () => {
  const r = await fetch(url, { method: 'POST', headers: { ...HEADERS, Origin: 'https://evil.example' }, body: '{}' });
  assert.equal(r.status, 403);
});
test('GET is not a valid MCP call', async () => {
  const r = await fetch(url, { method: 'GET', headers: HEADERS });
  assert.equal(r.status, 405);
});
test('missing MCP Accept header is rejected', async () => {
  const r = await fetch(url, { method: 'POST', headers: { ...HEADERS, Accept: 'application/json' }, body: '{}' });
  assert.equal(r.status, 406);
});
test('path traversal to host private files is rejected', async () => {
  const result = await tool('read_text_file', { path: '../../etc/passwd' });
  assert.equal(result.isError, true);
  assert.match(result.content[0].text, /traversal/i);
});
test('absolute paths are rejected', async () => {
  const result = await tool('read_text_file', { path: '/etc/passwd' });
  assert.equal(result.isError, true);
});
test('symlink crossing workspace is rejected', async () => {
  const result = await tool('read_text_file', { path: 'outside-link' });
  assert.equal(result.isError, true);
  assert.match(result.content[0].text, /symbolic/i);
});
test('read a permitted file with line bounds', async () => {
  const result = await tool('read_text_file', { path: 'fixture.txt', start_line: 2, end_line: 2 });
  assert.equal(result.isError, false);
  assert.equal(JSON.parse(result.content[0].text).content, 'beta');
});
test('create file / disallow overwrite by default / targeted edit', async () => {
  let r = await tool('write_text_file', { path: 'new.txt', content: 'hello' });
  assert.equal(r.isError, false);
  r = await tool('write_text_file', { path: 'new.txt', content: 'destroyed' });
  assert.equal(r.isError, true);
  r = await tool('edit_text_file', { path: 'new.txt', old_text: 'hello', new_text: 'world' });
  assert.equal(r.isError, false);
  assert.equal(await fs.readFile(path.join(workspace, 'new.txt'), 'utf8'), 'world');
});
test('edit must match exactly once', async () => {
  const r = await tool('edit_text_file', { path: 'fixture.txt', old_text: 'not present', new_text: 'ok' });
  assert.equal(r.isError, true);
  assert.equal(await fs.readFile(path.join(workspace, 'fixture.txt'), 'utf8'), 'alpha\nbeta\ngamma');
});
test('create directory, find and move within workspace', async () => {
  let r = await tool('create_directory', { path: 'project' });
  assert.equal(r.isError, false);
  r = await tool('move_file', { from: 'new.txt', to: 'project/moved.txt' });
  assert.equal(r.isError, false);
  const search = await tool('find_files', { name_contains: 'moved' });
  assert.ok(JSON.parse(search.content[0].text).matches.includes('project/moved.txt'));
  assert.equal((await tool('list_directory', { path: 'project' })).isError, false);
});
test('delete_file tool cannot be called when disabled', async () => {
  const r = await tool('delete_file', { path: 'fixture.txt' });
  assert.equal(r.isError, true);
  assert.equal(await fs.readFile(path.join(workspace, 'fixture.txt'), 'utf8'), 'alpha\nbeta\ngamma');
});
test('standalone Docker installer uses loopback and restrictive options without Compose', async () => {
  const installer = await fs.readFile(new URL('../scripts/install.sh', import.meta.url), 'utf8');
  for (const marker of ['127.0.0.1:$PORT:8787', '--read-only', '--security-opt no-new-privileges:true', '--cap-drop ALL', '--internal', '--pids-limit 40', '--memory 192m', '--env FRC_ALLOW_DELETE=0', '--user "$RUNTIME_UID:$RUNTIME_UID"', 'docker run --detach']) {
    assert.ok(installer.includes(marker), `missing security option ${marker}`);
  }
  assert.ok(!installer.includes('/var/run/docker.sock'));
  assert.ok(!installer.includes('--privileged'));
  assert.ok(!installer.includes('--network host'));
  assert.ok(!installer.includes('docker compose'));
  assert.ok(!installer.includes('systemctl restart docker'));
});
