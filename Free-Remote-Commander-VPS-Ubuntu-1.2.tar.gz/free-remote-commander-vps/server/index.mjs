import http from 'node:http';
import { createFileTools } from './files.mjs';

const MAX_JSON_BYTES = 1536 * 1024;
const PROTOCOL = '2025-11-25';
function rpcResult(id, result) { return { jsonrpc: '2.0', id, result }; }
function rpcError(id, code, message) { return { jsonrpc: '2.0', id, error: { code, message } }; }

export async function buildServer({ workspace, pathSecret, allowDelete = false, allowedOrigin = '' }) {
  if (typeof pathSecret !== 'string' || !/^\/mcp\/[a-f0-9]{64}$/.test(pathSecret)) {
    throw new Error('FRC_MCP_PATH must be /mcp/ followed by 64 hexadecimal characters');
  }
  const files = createFileTools(workspace, { allowDelete });
  await files.init();
  const server = http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    const respond = (status, payload) => {
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify(payload));
    };
    if (req.url === '/health' && req.method === 'GET') return respond(200, { status: 'ok' });
    // Capability URL: TLS is mandatory for public access. Do not log the URL.
    if (req.url !== pathSecret) return respond(404, { error: 'Not found' });
    if (req.headers.origin && req.headers.origin !== allowedOrigin) return respond(403, { error: 'Origin forbidden' });
    if (req.method !== 'POST') return respond(405, { error: 'Use POST' });
    if (!req.headers['content-type']?.toLowerCase().startsWith('application/json')) return respond(415, { error: 'Expected application/json' });
    if (!req.headers.accept?.includes('application/json') || !req.headers.accept?.includes('text/event-stream')) {
      return respond(406, { error: 'MCP Accept header must allow JSON and event-stream' });
    }
    const chunks = [];
    try {
      let count = 0;
      for await (const chunk of req) {
        count += chunk.length;
        if (count > MAX_JSON_BYTES) { respond(413, { error: 'Request too large' }); req.resume(); return; }
        chunks.push(chunk);
      }
      const message = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (!message || Array.isArray(message) || message.jsonrpc !== '2.0' || typeof message.method !== 'string') {
        return respond(400, rpcError(null, -32600, 'Invalid JSON-RPC request'));
      }
      const { method, id, params } = message;
      if (id === undefined) { res.writeHead(202); return res.end(); }
      if (typeof id !== 'number' && typeof id !== 'string') return respond(400, rpcError(null, -32600, 'Invalid JSON-RPC id'));
      if (method === 'initialize') return respond(200, rpcResult(id, {
        protocolVersion: PROTOCOL,
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'free-remote-commander-vps', version: '1.2.0' }
      }));
      if (method === 'ping') return respond(200, rpcResult(id, {}));
      if (method === 'tools/list') return respond(200, rpcResult(id, { tools: files.tools }));
      if (method === 'resources/list' || method === 'prompts/list') return respond(200, rpcResult(id, method === 'resources/list' ? { resources: [] } : { prompts: [] }));
      if (method === 'tools/call') {
        const name = params?.name;
        const args = params?.arguments ?? {};
        if (!Object.hasOwn(files.handlers, name)) return respond(200, rpcResult(id, {
          content: [{ type: 'text', text: 'Unknown or disabled tool' }], isError: true
        }));
        if (!args || Array.isArray(args) || typeof args !== 'object') return respond(400, rpcError(id, -32602, 'Invalid tool arguments'));
        try {
          const result = await files.handlers[name](args);
          return respond(200, rpcResult(id, { content: [{ type: 'text', text: JSON.stringify(result) }], isError: false }));
        } catch (e) {
          // Avoid revealing absolute filesystem paths or host configuration.
          const code = e.code;
          const safeMessage = code === 'ENOENT' ? 'File or directory not found' :
            code === 'EACCES' || code === 'EPERM' ? 'Access denied within workspace' :
            code === 'EEXIST' ? 'File or directory already exists' :
            code === 'EISDIR' ? 'Expected file but found directory' :
            code ? 'Filesystem operation failed' : e.message;
          return respond(200, rpcResult(id, { content: [{ type: 'text', text: safeMessage }], isError: true }));
        }
      }
      return respond(200, rpcError(id, -32601, 'Unknown method'));
    } catch {
      if (!res.headersSent) respond(400, rpcError(null, -32700, 'Malformed request'));
    }
  });
  server.headersTimeout = 10000;
  server.requestTimeout = 15000;
  server.maxRequestsPerSocket = 50;
  return server;
}

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href) {
  try {
    const server = await buildServer({
      workspace: process.env.FRC_WORKSPACE || '/workspace',
      pathSecret: process.env.FRC_MCP_PATH,
      allowDelete: process.env.FRC_ALLOW_DELETE === '1',
      allowedOrigin: process.env.FRC_ALLOWED_ORIGIN || ''
    });
    const port = Number(process.env.FRC_LISTEN_PORT || 8787);
    server.listen(port, '0.0.0.0', () => console.error(`MCP workspace service listening on internal port ${port}`));
  } catch (e) { console.error('Startup error:', e.message); process.exit(1); }
}
