import fs from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const LIMIT = 1024 * 1024;
const MAX_RESULTS = 100;
const utf8 = new TextDecoder('utf-8', { fatal: true });

function ensureString(value, label, max = 4096) {
  if (typeof value !== 'string' || !value.length || value.length > max) {
    throw new Error(`${label} must be a non-empty string (max ${max} characters)`);
  }
  return value;
}

export function createFileTools(workspace, { allowDelete = false } = {}) {
  let root;
  const init = async () => {
    root = await fs.realpath(workspace);
    const st = await fs.stat(root);
    if (!st.isDirectory()) throw new Error('WORKSPACE must be a directory');
    return root;
  };

  const safePath = async (input, { allowMissingLeaf = false, allowRoot = false } = {}) => {
    ensureString(input, 'path', 1024);
    if (input === '.') {
      if (!allowRoot) throw new Error('Workspace root cannot be modified');
      return root;
    }
    // Linux-only POSIX relative paths. Never resolve untrusted absolute paths.
    if (input.startsWith('/') || input.includes('\\') || input.includes('\0')) {
      throw new Error('Only relative Linux paths inside the workspace are permitted');
    }
    const parts = input.split('/');
    if (parts.some(p => p === '' || p === '.' || p === '..')) throw new Error('Invalid path traversal or empty segment');
    let current = root;
    for (let i = 0; i < parts.length; i++) {
      current = path.join(current, parts[i]);
      try {
        const st = await fs.lstat(current);
        if (st.isSymbolicLink()) throw new Error('Symbolic links are forbidden');
        if (i < parts.length - 1 && !st.isDirectory()) throw new Error('Parent path is not a directory');
      } catch (e) {
        if (e.code === 'ENOENT' && allowMissingLeaf && i === parts.length - 1) return current;
        throw e;
      }
    }
    if (current !== root && !current.startsWith(root + path.sep)) throw new Error('Path outside workspace');
    return current;
  };

  async function readText(file) {
    const fd = await fs.open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const st = await fd.stat();
      if (!st.isFile()) throw new Error('Not a regular file');
      if (st.size > LIMIT) throw new Error('File exceeds 1 MiB safety limit');
      const contents = await fd.readFile();
      if (contents.includes(0)) throw new Error('Binary files cannot be read as text');
      return utf8.decode(contents);
    } finally { await fd.close(); }
  }

  async function writeText(file, content, overwrite = false) {
    if (typeof content !== 'string' || Buffer.byteLength(content, 'utf8') > LIMIT) {
      throw new Error('content must be text of at most 1 MiB');
    }
    const flags = overwrite
      ? constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW
      : constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW;
    const fd = await fs.open(file, flags, 0o600);
    try {
      const st = await fd.stat();
      if (!st.isFile()) throw new Error('Not a regular file');
      await fd.writeFile(content, 'utf8');
    } finally { await fd.close(); }
    return `Saved ${Buffer.byteLength(content, 'utf8')} bytes`;
  }

  async function safeAtomicReplace(file, data) {
    const tmp = path.join(path.dirname(file), `.${path.basename(file)}.frc-${crypto.randomBytes(8).toString('hex')}`);
    try {
      await writeText(tmp, data, false);
      // atomic replacement; do not follow any symlink at the destination
      await fs.rename(tmp, file);
    } finally { await fs.rm(tmp, {force: true}).catch(() => {}); }
  }

  const handlers = {
    async list_directory({ path: p = '.' } = {}) {
      const dir = await safePath(p, { allowRoot: true });
      const list = await fs.readdir(dir, { withFileTypes: true });
      return { path: p, total: list.length, entries: list.slice(0, MAX_RESULTS).map(e => ({ name: e.name, type: e.isSymbolicLink() ? 'symlink-blocked' : e.isDirectory() ? 'directory' : e.isFile() ? 'file' : 'other' })), truncated: list.length > MAX_RESULTS };
    },
    async read_text_file({ path: p, start_line: start = 1, end_line: end } = {}) {
      const file = await safePath(p);
      const content = await readText(file);
      const lines = content.split('\n');
      if (!Number.isInteger(start) || start < 1 || start > lines.length) throw new Error('Invalid start_line');
      const stop = end === undefined ? Math.min(lines.length, start + 399) : end;
      if (!Number.isInteger(stop) || stop < start || stop - start > 399) throw new Error('Invalid end_line (max 400 lines per call)');
      return { path: p, start_line: start, end_line: Math.min(stop, lines.length), total_lines: lines.length, content: lines.slice(start - 1, stop).join('\n') };
    },
    async write_text_file({ path: p, content, overwrite = false } = {}) {
      const file = await safePath(p, { allowMissingLeaf: true });
      return { path: p, result: await writeText(file, content, overwrite === true) };
    },
    async edit_text_file({ path: p, old_text: old, new_text: replacement } = {}) {
      ensureString(old, 'old_text', LIMIT);
      if (typeof replacement !== 'string') throw new Error('new_text must be a string');
      const file = await safePath(p);
      const content = await readText(file);
      const count = content.split(old).length - 1;
      if (count !== 1) throw new Error(`Expected exactly one matching block; found ${count}`);
      const next = content.replace(old, replacement);
      if (Buffer.byteLength(next, 'utf8') > LIMIT) throw new Error('Edited file exceeds 1 MiB');
      await safeAtomicReplace(file, next);
      return { path: p, result: 'One unique text block replaced' };
    },
    async create_directory({ path: p } = {}) {
      const dir = await safePath(p, { allowMissingLeaf: true });
      await fs.mkdir(dir, { mode: 0o700 });
      return { path: p, result: 'Directory created' };
    },
    async get_file_info({ path: p } = {}) {
      const target = await safePath(p, { allowRoot: true });
      const st = await fs.lstat(target);
      return { path: p, type: st.isDirectory() ? 'directory' : st.isFile() ? 'file' : 'other', size_bytes: st.size, last_modified: st.mtime.toISOString() };
    },
    async find_files({ path: p = '.', name_contains: q, max_depth: depth = 5 } = {}) {
      ensureString(q, 'name_contains', 200);
      if (!Number.isInteger(depth) || depth < 0 || depth > 8) throw new Error('max_depth must be 0 to 8');
      const start = await safePath(p, { allowRoot: true });
      const results = [];
      const stack = [[start, 0]];
      let scanned = 0;
      while (stack.length && scanned < 2000 && results.length < 50) {
        const [dir, level] = stack.pop();
        const entries = await fs.readdir(dir, { withFileTypes: true });
        for (const entry of entries) {
          if (++scanned > 2000) break;
          const filename = path.join(dir, entry.name);
          if (entry.isSymbolicLink()) continue;
          if (entry.name.toLowerCase().includes(q.toLowerCase())) results.push(path.relative(root, filename));
          if (results.length >= 50) break;
          if (entry.isDirectory() && level < depth) stack.push([filename, level + 1]);
        }
      }
      return { matches: results, scanned, truncated: scanned >= 2000 || results.length >= 50 };
    },
    async move_file({ from, to } = {}) {
      const src = await safePath(from);
      const dest = await safePath(to, { allowMissingLeaf: true });
      if (!(await fs.lstat(src)).isFile()) throw new Error('Only regular files may be moved');
      try { await fs.lstat(dest); throw new Error('Destination already exists'); }
      catch (e) { if (e.code !== 'ENOENT') throw e; }
      await fs.rename(src, dest);
      return { from, to, result: 'File moved' };
    }
  };
  if (allowDelete) handlers.delete_file = async ({ path: p } = {}) => {
    const file = await safePath(p);
    if (!(await fs.lstat(file)).isFile()) throw new Error('Only regular files can be deleted');
    await fs.unlink(file);
    return { path: p, result: 'File deleted' };
  };

  const toolSpecs = [
    ['list_directory', 'List up to 100 direct entries in one workspace directory.', { path: { type: 'string', description: 'Relative path, or . for workspace root' } }, []],
    ['read_text_file', 'Read at most 400 lines of a text file, up to 1 MiB.', { path: { type: 'string' }, start_line: { type: 'integer', minimum: 1 }, end_line: { type: 'integer', minimum: 1 } }, ['path']],
    ['write_text_file', 'Create a UTF-8 file (no overwrites unless overwrite=true). Maximum 1 MiB.', { path: { type: 'string' }, content: { type: 'string' }, overwrite: { type: 'boolean' } }, ['path','content']],
    ['edit_text_file', 'Replace exactly one matching text block in a file.', { path: { type: 'string' }, old_text: { type: 'string' }, new_text: { type: 'string' } }, ['path','old_text','new_text']],
    ['create_directory', 'Create one directory. Parent directory must already exist.', { path: { type: 'string' } }, ['path']],
    ['get_file_info', 'Read metadata of a workspace file or directory.', { path: { type: 'string' } }, ['path']],
    ['find_files', 'Find filenames within workspace, limited to depth 8, 2000 entries, 50 matches.', { path: { type: 'string' }, name_contains: { type: 'string' }, max_depth: { type: 'integer', minimum: 0, maximum: 8 } }, ['name_contains']],
    ['move_file', 'Rename/move one regular file within workspace; target must not exist.', { from: { type: 'string' }, to: { type: 'string' } }, ['from','to']]
  ];
  if (allowDelete) toolSpecs.push(['delete_file', 'Delete one regular file inside workspace. Explicitly enabled by administrator.', { path: { type: 'string' } }, ['path']]);

  const tools = toolSpecs.map(([name, description, properties, required]) => ({
    name, description, inputSchema: { type: 'object', properties, required, additionalProperties: false },
    annotations: { readOnlyHint: ['list_directory','read_text_file','get_file_info','find_files'].includes(name), destructiveHint: name === 'delete_file', openWorldHint: false }
  }));

  return { init, handlers, tools };
}
