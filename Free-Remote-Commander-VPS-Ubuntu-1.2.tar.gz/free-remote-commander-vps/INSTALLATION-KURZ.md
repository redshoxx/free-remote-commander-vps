# VPS-Installation mit vorhandener Docker Engine 29.1.3

**Keine Aenderungen an `nolimits-wardogs-v2`, Nginx, PostgreSQL, Docker-Daemon oder UFW vornehmen.**

1. Paket sicher auf den VPS unter `/root` uebertragen (ueber einen genehmigten Weg).
2. VNC-Konsole als root:

```bash
cd /root
tar -xzf Free-Remote-Commander-VPS-Ubuntu-1.2.tar.gz
cd free-remote-commander-vps
bash scripts/install.sh
bash scripts/verify.sh
```

3. Nur wenn neun Sicherheitschecks OK anzeigen, den MCP-Zugang weiter vorbereiten.
4. **Weder `.env` noch `docker inspect` oder die vollstaendige private URL in Screenshots teilen.**

Rueckbau im Projektverzeichnis:

```bash
bash scripts/uninstall.sh
```

**Nicht** `docker system prune`, `docker network prune`, `apt upgrade`,
`systemctl restart docker` oder ein fremdes Projekt `docker compose down` ausfuehren.

Falls `tar -xzf` scheitert: Installation anhalten, zuerst die Paketdatei pruefen.
